../bin/MetBaN.sh ./data/1_S1_L001_R1_001.fastq ./data/1_S1_L001_R2_001.fastq -i "33836 33849 33853" -g ./data/Bolidomonas_outgroup.fas -r ecoPCR_database -d embl_last/ -o test_results -b 10
